#pragma once

#include "IBitmapGen.h"

#ifdef _WIN32

class CBitmapGenGdiplus:public IBitmapGen
{
private:
	static ULONG_PTR gdiplusToken;

	std::wstring fontname;
	int fontheight;
public:
	static void Initialize();
	static void Shutdown();

	CBitmapGenGdiplus();
	CBitmapGenGdiplus(const IBitmapGenParameters* params);
	virtual ~CBitmapGenGdiplus();
	virtual std::shared_ptr<libCZI::IBitmapData> Create(libCZI::PixelType pixeltype, std::uint32_t width, std::uint32_t height, const BitmapGenInfo& info);
private:
	static void ConvertRgb24ToBgr24(std::uint32_t w, std::uint32_t h, std::uint32_t stride, void* ptrData);
};

#endif