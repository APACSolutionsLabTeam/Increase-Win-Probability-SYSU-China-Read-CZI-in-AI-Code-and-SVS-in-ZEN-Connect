#pragma once
#include "cmdlineoptions.h"

bool executeCreateCzi(const CCmdLineOptions& options);
