#pragma once

#define  _LIBCZISTATICLIB
#include <libCZI.h>
