#pragma once

// If building with CMake, there will be a file "libCZI_Config.h" created/configured by
// CMake. In order to enable building with the .sln-file in VisualStudio we use a somewhat
// lame approach - we use some preprocessor define in order to use definitions which are
// static (not generated) here.

#if defined(VISUALSTUDIO_PROJECT_BUILD)

	#define CZICMD_USE_WIC						1
	#define CZICMD_USE_LIBPNG					0
	#define CZICMD_USE_FREETYPE					0
	#define CZICMD_USE_GDIPLUS					1

#else

	#include <CZIcmd_Config.h>

#endif
