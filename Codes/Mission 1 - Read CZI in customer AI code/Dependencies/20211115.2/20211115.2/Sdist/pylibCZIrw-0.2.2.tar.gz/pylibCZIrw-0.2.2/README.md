# IMPORTANT - READ THE FOLLOWING LINE CAREFULLY
If you intend to **use** this repo, clone the repository on your machine with ``` git clone --recurse-submodules ```.  
If you intend to also **contribute** to this repo, you are requested to copy ALL files in the hooks directory into your .git/hooks directory right after you cloned this repo! In addition, be sure to ideally always keep your remotes up-to-date with ``` git pull --recurse-submodules ```. Even better, you can set the configuration option _submodule.recurse_ to _true_ locally (this works for git pull since Git 2.15) with ``` git config --local submodule.recurse true ```. This option will make Git use the _--recurse-submodules_ flag for all commands that support it (except clone). See https://git-scm.com/book/en/v2/Git-Tools-Submodules for more information.

# Status

[![pylibCZIrw package in RMS-PyPI feed in Azure Artifacts](https://feeds.dev.azure.com/ZEISSgroup/e9a62f99-7d3f-49b4-8adf-ae4125007274/_apis/public/Packaging/Feeds/e99db8ac-e487-486d-9bda-cd3205df80bc/Packages/3d37ae19-df0d-4f5b-b90b-387a83f90df9/Badge)](https://dev.azure.com/ZEISSgroup/RMS-DEV/_packaging?_a=package&feed=e99db8ac-e487-486d-9bda-cd3205df80bc&package=3d37ae19-df0d-4f5b-b90b-387a83f90df9&preferRelease=true)  
[![Build Status](https://dev.azure.com/ZEISSgroup/RMS-DEV/_apis/build/status/TC/Projects/TC-PyPI-pylibCZIrw?branchName=main)](https://dev.azure.com/ZEISSgroup/RMS-DEV/_build/latest?definitionId=5108&branchName=main)

# Introduction 

czi is a python wrapper around the [libCZIrw C++ library](https://dev.azure.com/ZEISSgroup/RMS-DEV/_git/libCZIrw).

Similar endeavours have been made to wrap libCZI in python, namely:
- [pylibCZI](https://github.com/elhuhdron/pylibczi)
- [aicspylibCZI](https://github.com/AllenCellModeling/aicspylibczi)

This python package has a slightly different API with some improvements to reading but, more importantly, the addition of writing functionality.

There are also libCZI wrappers for other languages:
- [Mathematica / Wolfram Language](https://github.com/ptahmose/WolframLibraryLink_libCZI)
- [Matlab/Octave via MEXFile](https://github.com/ptahmose/MEXlibCZI)

This is an internal package even though there is a vision to make it public.

For more information please contact the ENCHILADA team.

**LibCZI**

libCZI is a well documented library. The most extensive documentation can be found [here](https://ptahmose.github.io/libCZI-doc/index.html).

There are different git repos with libCZI and thus, different versions exist.

The code in this repo wraps the libCZI in the [RMS_libCZIrw](https://dev.azure.com/ZEISSgroup/RMS-DEV/_git/libCZIrw) repo, which is the only repo where libCZI exposes a write API.

Other existing repos are:
- [Zeiss libCZI](https://github.com/zeiss-microscopy/libCZI) on GitHub
- [Juergen Bohl's repo](https://github.com/ptahmose/libCZI) on GitHub

# Building
***pylibCZIrw*** is a python library using bindings from:  
* [libCZIrw C++ library](https://dev.azure.com/ZEISSgroup/RMS-DEV/_git/libCZIrw) and  
* pybind11  
  - a very modern and maintained project (Supports c++11/c++14 features)  
  - Bindings are done in a very few lines of code, interface with numpy array is easy.
  - No need to "learn" and code in an intermediate language (Cython).
  - Already used internally at Zeiss and very good feedbacks.

To contribute to the development (C++ or python side), you will have to compile the C++ bindings.
This documentation provides a step by step guide to help you to do so.

## Requirements

- 64 bits OS and 64 bits Python (with [cmake pre-installed](https://cmake-python-distributions.readthedocs.io/en/latest/installation.html)). 
- ***python 3.XX***
- C++ compiler (***clang/gcc*** for linux, ***VS Studio*** on ***Windows***).

## Getting started

- Make sure that the libs folder contains ***libCZIrw*** and ***pybind11*** submodules (i. e. those subfolders are not empty).

## Building on Windows

### Using PyCharm (or plain Python console)
0. ``` pip install --use-feature=in-tree-build .[all]``` from the root of the repo.
1. You can import this library in python and start using the bindings. 
```from pylibCZIrw import czi ```

### Using Visual Studio > 2015
0. Create an environment variable PYTHON_EXECUTABLE that contains the full path to python.exe (needed for pybind11)
1. Launch ***Visual Studio***.
Click Open a local folder and select RMS_PyPI_pylibCZIrw.
It will automatically load the ***Cmake*** project.

2. To build the project right click on the **CmakeList.txt** at the root of the repo and select Build.
If it fails with the linking error **LNK1104 cannot open file 'python3X_d.lib'**, try to select the **"x64-Release"** config instead of **"x64-Debug"** 
(some ***Windows*** installation of python are missing the debug .dll version (dynamic libraries)).

4. If the Build was successful it should have generate a python library file **_pylibCZIrw.cp<python-version>-win_amd64.pyd** in the corresponding build folder.

5. Copy this file to the root of the repo and rename it to _pylibCZIrw.pyd

5. You can import this library in python and start using the bindings. 
```from _pylibCZIrw import czi ```

## Building on Linux

Not done yet.

# Branching
This repository follows a trunk-based branching model with the main development branch __main__ being the production branch.

# Versioning
This [package](#packaging) follows [Semantic Versioning](https://semver.org/).  

For the sake of simplicity, **any** source code change that will eventually go into the __main__ development [branch](#branching) needs to be accompanied by an update to the version number in setup.py, i.e. no filtering on source code level is carried out. 

# Packaging

A package installable through pip is [generated as part of a CI/CD pipeline](https://docs.microsoft.com/en-us/azure/devops/pipelines/artifacts/pypi?view=azure-devops&tabs=yaml). 

Upon a CI trigger on __main__, the package is pushed to the default [view](https://docs.microsoft.com/en-us/azure/devops/artifacts/concepts/views?view=azure-devops) of the [project-scoped](https://docs.microsoft.com/en-us/azure/devops/artifacts/feeds/project-scoped-feeds?view=azure-devops) artifacts feed [RMS-PyPI](https://dev.azure.com/ZEISSgroup/RMS-DEV/_packaging?_a=feed&feed=RMS-PyPI). This feed is also configured to pull [PyPI as upstream source](https://docs.microsoft.com/en-us/azure/devops/artifacts/concepts/upstream-sources?view=azure-devops).

Note: Each trigger on __main__ requires the [version](#versioning) in setup.py to be incremented to comply with the [key concepts for Azure Artifacts](https://docs.microsoft.com/en-us/azure/devops/artifacts/artifacts-key-concepts?view=azure-devops). Failing to do so will result in the CI pipeline failing.

Authentication is based on [keyring](https://docs.microsoft.com/en-us/azure/devops/artifacts/quickstarts/python-packages?view=azure-devops).

The package then needs to be [promoted](https://docs.microsoft.com/en-us/azure/devops/artifacts/feeds/views?view=azure-devops) manually on demand once the package is deemed to be stable/qualified. Old package versions that have not been promoted are subject to a [retention policy](https://docs.microsoft.com/en-us/azure/devops/artifacts/how-to/delete-and-recover-packages?view=azure-devops&tabs=maven#automatically-delete-old-package-versions-with-retention-policies).

For organizations planning to [consume this package](https://docs.microsoft.com/en-us/azure/devops/artifacts/concepts/best-practices?view=azure-devops#consume-packages), this feed is to be referenced following this [guideline](https://docs.microsoft.com/en-us/azure/devops/artifacts/how-to/set-up-upstream-sources?view=azure-devops#add-an-azure-artifacts-feed-in-a-different-organization-within-your-azure-ad-tenant-as-an-upstream-source).

# Installation
Binary wheels for all python versions that this package is considered to be compatible against (see python_requires in setup.py) as well as a source distribution are [packaged](#packaging). Installing from the source distribution requires __cmake__ to be available on PATH. 

1. ``` python -m pip install --upgrade --requirement requirements.txt``` (essentially needed for keyring and artifacts-keyring to be available)
2. ``` python -m pip install pylibCZIrw --index-url https://pkgs.dev.azure.com/ZEISSgroup/RMS-DEV/_packaging/RMS-PyPI/pypi/simple ```
3. Complete authentication (varies based on the concrete method)

# API Specification
**Table of Contents**
- [Opening a CZI (read-only)](#opening-a-czi-read-only)
- [Reading a CZI](#reading-a-czi)
  - [Reading dimension information](#reading-dimension-information)
  - [Reading metadata](#reading-metadata)
  - [Reading pixel type](#reading-pixel-type)
  - [Reading pixel data](#reading-pixel-data)
    - [Signature](#signature)
     - [`read(**kwargs)`](#readkwargs)
     - [roi (optional)](#roi)
     - [plane (optional)](#plane)
     - [scene (optional)](#scene)
     - [zoom (optional)](#zoom)
     - [pixel_type (optional)](#pixel_type)
     - [background_pixel (optional)](#background_pixel)
- [Creating a CZI](#creating-a-czi)
- [Writing a CZI](#writing-a-czi)
  - [Writing pixel data](#writing-pixel-data)
    - [Signature](#signature-1)
     - [`write(data, **kwargs)`](#writedata-kwargs)
     - [data (required)](#data)
     - [location (optional)](#location)
     - [plane (optional)](#plane)
     - [scene_index (optional)](#scene_index)
  - [Writing metadata](#writing-metadata)
    - [channel_information (required)](#channel_information)
  - [Writing Example](#writing-example)
- [Advanced Topics](#advanced-topics)

## Opening a CZI (read-only)

A CZI file can be opened in a context manager using a [path-like-object](https://docs.python.org/3/library/os.html#os.PathLike) (in this case, file_path).

`with czi.open_czi(file_path) as czi:`

Or directly using a [stream](https://docs.python.org/3/library/io.html).

**This will open the CZI in read-only mode.**

**Note**: Internally, the library works with streams. Like done in [aicspylibczi](https://github.com/AllenCellModeling/aicspylibczi/blob/f00b6eb4042246cd28a527c5964f3e946ed84c7e/aicspylibczi/CziFile.py#L48) If this is correctly implemented, otherwise, lets start using file path only.

## Reading a CZI

The following calls all relate to reading information from the CZI. And, whenever they're called, the file's last write date will be evaluated and cached. **If the file was changed while opened, all file caches will be invalidated.**

### Reading dimension information
The czi object will have some methods to extract specific information from the CZI.

The plane dimensions (i.e. C, T, Z, H, B, etc) are constant across scenes.
We will treat scenes differently at this level for the sake of consistency. The following three calls mimic the concept of [SubBlockStatistics](https://ptahmose.github.io/libCZI-doc/structlib_c_z_i_1_1_sub_block_statistics.html#a10b6e7fb9312e93b1e9785daed56e44e) in libCZI.

**`total_bounding_box`**

*Returns:* Dictionary with the existing plane dimensions and their range. Example: `{'C': (0, 3), 'Z': (0, 4), 'T': (0,7), 'X': (0, 975), 'Y': (0, 825)}`.

**The plane dimensions are constant across scenes.**

*Default:* X, Y, C, Z, and T will always be returned even if there's no such information, in which case their default value will be (0, 1). Other dimensions (e.g. H, B, etc.) will **not** be returned if not present.

**Note**: It is possible, though rarely, that the minimum index of a plane is less than zero.

**`scene_bounding_rectangles`**

*Returns:* Dictionary where the keys are the scenes and the value their bounding rectangles. [Same as in libCIZ](https://ptahmose.github.io/libCZI-doc/structlib_c_z_i_1_1_sub_block_statistics.html#ab02ae7bcd25f34008ec9d5afa8a4efec). Example:  `{ 0: (0, 0, 475, 325), 1: (500, 500, 900, 800) }`

**Important:** If there are no scenes, we return empty.

**`total_bounding_rectangle`**

*Returns:* The bounding rectangle of the whole CZI. Same as [boundingBox](https://ptahmose.github.io/libCZI-doc/structlib_c_z_i_1_1_sub_block_statistics.html#a924c2adf7f3e132470dfeb06ea1e958c).

**Note**: The total bounding rectangle can also be inferred from the X and Y values returned by the `total_bounding_box` call.

### Reading metadata

**`raw_metadata`**

*Returns:* The raw metadata of the czi as a string.

**Important:** Even though libCZI can retrieve specialized metadata, for simplicity's sake. we will stick with getting the whole raw metadata and manipulate it at the python level like Sebi does [here](https://github.com/sebi06/czi_demos/blob/master/imgfile_tools.py).

### Reading pixel type

**`get_channel_pixel_type(channel_index)`**

*Returns:* The pixel type of the channel with the specified index, e.g. 'gray8'. 
*Default:* Defaults to the minimum channel index. As mentioned above, if there is no C index in the CZI (uncommon and pathological case), the C index still defaults to 0.

**`pixel_types`**

*Returns:* Dictionary whose keys are the channel indices, and the values the channel's pixel types, e.g.  {0: 'gray8', 1: 'bgr24'}

LibCZI's strategy for finding a channel's pixel type is by checking the pixel type of the first subblock. This is further discussed in [**Discovery**](#discovery).

### Reading pixel data

LibCZI offers different ways of reading the pixel data:

![image info](/doc/images/libczi_access_types.png)

We will use the [Single Channel Scaling Accessor](https://ptahmose.github.io/libCZI-doc/classlib_c_z_i_1_1_i_single_channel_scaling_tile_accessor.html). And, to start simple, the python api should resemble what the [libCZI exposes](https://ptahmose.github.io/libCZI-doc/classlib_c_z_i_1_1_i_single_channel_scaling_tile_accessor.html).

<span style="color: #FF2C00">Important</span> considerations regarding the Single Channel Scaling Accessor:

- Subblocks of different scenes CANNOT overlap. When they do, we get undefined behaviour. This assumption allows for no ambiguity about the returned data when the roi spans across multiple scenes.
- Images might have overlapping tiles/subblocks, this is particularly the case for non-stitched images. When getting pixel data from regions with overlapping subblocks (within the same scene), the subblock with the highest M-index wins.
If tile-wise processing or any other processing that accounts for subblock arrangement is needed, new methods must be provided that bind to [libCZI's subblock accessor](https://ptahmose.github.io/libCZI-doc/classlib_c_z_i_1_1_i_sub_block_repository.html).

#### `read(**kwargs)`

*Returns:* The pixel data as a **numpy array**, the shape of the returned array and its data type will depend on the specified `pixel_type`.
- BGR pixel type -> [y, x, 3]
- Gray pixel type -> [y, x, 1]

This is further explained in the [pixel type parameter description](#pixel_type)

#### roi
**Optional**  
The **roi is a tuple** defined as a (axis-aligned) rectangle in (x, y, w, h) form, with:
- x: x coordinate of upper-left point
- y: y coordinate of upper-left point
- w: rectangle width
- h: rectangle height

**The maximum roi size is the total bounding rectangle.**

*Default:* The roi default depends on the scene parameter:
- No scene parameter: The roi defaults to the total bounding rectangle (`total_bounding_rectangle`)
- Scene parameter specified: The roi defaults to the bounding box of the specified scene.

**Important:** For CZIs with scenes of different shapes, not specifying the roi will return different shapes of data for each scene.

**Please check the section on [scenes](#scenes) section for examples on how to handle CZIs with different scene arrangements.**

#### plane
**Optional**  
The plane variable is a set of indices representing the coordinate of the planes to access. It is as dictionary whose keys are the dimension and the values are the coordinate value.
Example: dict {'C': 0, 'T': 1, 'Z': 4}

*Default:* Defaults to the minimum value for all plane coordinates, which can be known using `total_bounding_box`.

*Errors:* If any plane coordinate falls outside the existing bounds, an error is raised.

**Note:** There might be indices with negative indices, and there is no logic to deal with this case. It is up to the caller to deal with such scenarios.

#### scene
**Optional**  
The index of the scene to be considered. If set, only subblocks of the specified scene can contribute to the resulting bitmap.

*Default:* All scenes will be considered.

**Note:** Scenes are not orthogonal to the other dimensions and must therefore be handled differently. For more information please check the section on [scenes](#scenes) section.

#### zoom
**Optional**  
A float between 0 (excluded) and 1 that specifies the zoom factor.

The purpose of the zoom factor (like the ROI) is to facilitate the handling of large data that does not fit into the available memory. Using a zoom factor smaller than one will return less data. 

*Default:* The zoom defaults to 1, in which case, the returned array will have the same X,Y shape of the used ROI. Smaller zoom factors will return an array whose X,Y shape are smaller (in the proportion of the zoom factor) than the used ROI. For zoom levels different than 1, allocating the output bitmap needs to be done in 2 calls.

*Errors:* Zoom levels will throw at small enough levels.

#### pixel_type
**Optional**  
The pixel type of the returned data.

*Default:* Defaults to the pixel type of the channel being read.

Since a pixel type is always used internally, there will always be an implicit pixel conversion done by libCZI which will take care of the issue of having subblocks with different pixel types in the same channel.

Reading pixel types is further explained in the section on [reading pixel data](#reading-pixel-data) section.


#### background_pixel
**Optional**  
Specified the colour of the background pixels (pixels with no data).
This parameter naturally needs to be consistent with the returned pixel type:
|pixel_type | background_pixel type | Default value  | 
--- | --- | ---
|BGR|3-value tuple |(0, 0, 0)|
|Gray|Scalar value bounded by the gray scale|0|
|BGRA (If ever supported by libCZI)|4-value tuple|(0, 0, 0, 0)|

*Errors:* An exception will be raised if the wrong type is provided.

**Note:** In the future we hope to support masks to univocally identify invalid data.

## Creating a CZI

Like with opening, creating a new empty CZI can be done in a context manager using a [path-like-object](https://docs.python.org/3/library/os.html#os.PathLike) (in this case, file_path).

`with czi.create(file_path) as czi:`

This creates a new czi file at the provided path and **opens it in write mode.**

## Writing a CZI

### Writing pixel data

For the sake of consistency, we want to write data similarly to how we read it.

#### `write(data, **kwargs)`

Writes data as **a single subblock** in the CZI at a specific location.

#### data
**Required**  

The data (numpy array) to be written.

Writing 2D single non-BGR channel is done by providing a [1, y, x] array.
Writing a 2D single BGR channel is done by providing a [3, y, x] array.

The pixel type in which to write the data will be inferred from the numpy array data type following the rules described in [**Writing Pixel Data**](#writing-pixel-data).

**Note:** Data is expected in BGR. If the original data is in BGR format, rotation can be done simply by `bgr = rgb[...,::-1]`.

*Errors:* If the data is larger than 10MB, this call will throw. In order to write larger data, it needs to be broken down into chunks smaller than 10MB.

#### location
**Optional**  

The pixel coordinates of the upper-left pixel. This allows writing data in different regions in the selected 2D plane.

*Default:* Default value is (0, 0).

*Errors:* If there is already data at the specified position, the write call will raise an exception  (i.e. we cannot write overlapping subblocks).

#### plane
**Optional**  

Same concept of the read method. A dictionary specifying the plane coordinates of the data to be written.
Example: dict {'C': 0, 'T': 1, 'Z': 4}

An M index is cached per plane so that every new subblock written to the plane gets the next M-index (this is hidden from the user).

*Default:* All planes will default to 0, meaning that the size of each plane coordinate is at least 1.

*Errors:* If there is data with a different pixel type in the specified plane, the write call will raise an exception.

#### scene_index
**Optional**  

An integer specifying the scene index.

*Default:* If no scene index is specified the result document will have a single scene with index 0.

### Writing metadata

Metadata can be explicitly written with

**`write_metadata(document_name, channel_names)`**

If not explicitly written, metadata will be automatically written when closing the file.


libCZI allows writing metadata through the [IMetadataSegment](https://dev.azure.com/ZEISSgroup/RMS-DEV/_git/libCZIrw?path=%2FSrc%2FlibCZI%2FlibCZI_ReadWrite.h&version=GBreadwrite&line=82&lineEnd=82&lineStartColumn=3&lineEndColumn=71&lineStyle=plain&_a=contents) exposed in the ICziReaderWriter.
The IMetadataSegment is the root of a specialized object tree that provides access to specific metadata. We will start by exposing a single call to write channel information which will manipulate the [IDimensionChannelInfo](https://dev.azure.com/ZEISSgroup/RMS-DEV/_git/libCZIrw?path=%2FSrc%2FlibCZI%2FlibCZI_Metadata2.h&version=GBmaster&line=138&lineEnd=138&lineStartColumn=8&lineEndColumn=29&lineStyle=plain&_a=contents).

#### document_name
**Optional**  

The document name is an optional string parameter that sets the value of the Document.Title metadata node.

#### channel_names
**Optional**  

The channel names parameter is a dictionary whose keys are the channels' indices, and the values being a dictionary representing the channels' names.

**For now, we will only support changing the channel name**. So the only valid format is: ``{ 0: "C1", 1: "C2" }``

Future requirements like setting a channel's color will only require implementation at the C++ layer, with the python API having no change whatsoever. It simply will not break when setting the channel color anymore. 

Future things to implement:
- writing spatial relationship data instead of stage coordinates at subblocks.
- Add colour persistence to channel.

#### Writing Example

The following code illustrates how one can write a czi in a machine learning context.

```python

data = inference_service.run() # [2, y, x] array with 2 being the number of classes.

with czi.open_czi(path, 'w'):

    class_nuclei = data[0,:,:]
    channel_0 = { 'C': 0 }

    czi.write(data=class_nuclei, location=(0,0), plane=channel_0)

    class_background = data[1,:,:]
    channel_1 = { 'C': 1 }

    czi.write(data=class_background, location=(0,0), plane=channel_1)

    # If we stopped here, we'd have a valid CZI. But we want to name the channels after the classes.

    channel_names = { 0: "C1", 1: "C2" }

    czi.write_metadata(channel_names=channel_names)

```
## Advanced Topics
### Pixel Types

#### Discovery

Pixel type is a tricky topic. The following situations are possible:
- metadata has the correct pixel type
- metadata has an incorrect pixel type
- metadata does not have information about the pixel type
- pixel type is the same for all channels
- pixel type is different for different channels
- pixel type is different for different subblocks in the same channel

We will get the pixel type by looking at the first subblock (using libCZI).

#### Handling and Conversion

Data can be read and written in different pixel types, with BGR having some peculiarities.

##### Reading

**<span style="color:	#FF2C00">TO DO: pixel type to numpy data type conversion</span>**
read



write
[1, y, x]
uint8 -> gray8
uint16 -> gray16
float32 -> gray32 float
[3, y, x]
uint8 -> BGR24 (colour rotation, )
uint16 -> BGR48
float32 -> BGR96float (check if libCZI)



When reading, one can specify a destination pixel type. When the requested pixel type is different than the source's, libCZI converts it. The conversion is done as documented in the [libCZI documentation](https://ptahmose.github.io/libCZI-doc/accessors.html):

![pixel type conversion](/doc/images/pixel_type_conversion.png)

**Important: The shape of the last data dimension will always be expanded from 1 to 3 if the [destination pixel type](#pixel_type) is BGR (BGR24 or BGR48).**

This is similar to what is done in [aicspylibczi](https://github.com/AllenCellModeling/aicspylibczi/blob/575c440c6bf6a0a481dabd0b4ae4eb67f89dda26/aicspylibczi/CziFile.py#L342).


##### Writing

There is no pixel type conversion in place when writing. We must therefore add the necessary logic to the subblock creation process.

In both the low and high-level read APIs, if the pixel_type is set to BGR, the subblock creation will have to merge the channels found in the data array following the same conversion rules defined above.
**Important: The data must of therefore be consistent with the pixel type being written. Otherwise an error will be thrown**


### Masks
Regions with no data will be filled by libCZI with the background color. There is therefore no way to tell between a pixel having the color of the background or being really background/invalid.

*A hacky way of figuring it out is to request the same data twice with different background colors.*

The real solution to this problem is by leveraging the mask data that exists in the CZI. Masks indicate regions with invalid or no data. There are two cases:                
- simple case: there is no subblock at aspecific location
- advanced case: there is a subblock with mask data, indicating that there are parts with invalid pixels

However, there is no support (yet) for masks in libCZI. If we come to need it, it has to be implemented.

### Scenes
Scenes are not orthogonal to the other dimensions, they can be though of as "tags". Thus, handling them as other dimensions will cause more problems than it would help.

In a nutshell:
**The scene-index is not part of a plane-coordinate**

The arrangement below is possible:

![image info](/doc/images/scenes.png)

Getting the dimensions of this CZI would show these scenes having the following bounding boxes:

**S0:** X=0, Y=0, W=100, H=100
**S1:** X=80, Y=80, W=100, H=100

For orthogonal dimensions, one can loop through them using the same ROI and not run into troubles. (<span style="color:	#FF8C00">Or am I missing something?</span>)
However, in the situation above, looping through scenes with the same ROI would produce bogus data:

![image info](/doc/images/read_scenes.png)

So to avoid confusion we treat scenes differently. By having to deal with scenes separately, users will know that they're not just another dimension.

#### Images with no scenes

Let's say we have a single-channel CZI time series with no scenes:

![simple czi](/doc/scenes/no_scenes.png)

**Get dimensions information:**

```python
total_bounding_box = get_total_bounding_box()
scene_bounding_rectangle = czi.get_scene_bounding_rectangle()
total_bounding_rectangle = czi.get_total_bounding_rectangle()

print(total_bounding_box)
# {'C': 0, 'T': (0, 5), 'X': (0, 400), 'Y': (0, 600)}
print(scene_bounding_rectangle)
# ''
print(total_bounding_rectangle)
# '(0, 0, 400, 600)'
```
**Default read (no ROI)**

```python
for t in t_enumerable:
    data = czi.read(plane = { 'T': t })
```
Returns:

![default read](/doc/scenes/no_scenes.png)

**Specifying ROI:**

```python
for t in t_enumerable:
    roi = (0, 0, 200, 200)
    data = czi.read(roi=roi, plane = { 'T': t })
```
Returns:

![read at roi](/doc/scenes/no_scenes_result_roi.png)


#### Images with non-uniform scenes

Let's say we have a single-channel time series and z-stack CZI with scenes:

![multi-scene czi](/doc/scenes/scenes_image.png)


**Get dimensions information:**

```python
print(total_bounding_box)
# {'C': 0, 'T': (0, 5), 'Z': (0, 2), 'X': (0, 2000), 'Y': (0, 1400)}
```

In this case, scenes have different sizes/bounding boxes:

![bounding boxes](/doc/scenes/bounding_boxes.png)

```python
print(scene_bounding_rectangle)
# { 0: (800, 0, 1200, 500), 1: (0, 200, 1000, 1200), 2: (900, 600, 1100, 800)}
print(total_bounding_rectangle)
# { 0: (0, 0, 2000, 1400)}
```

**Default read (no ROI)**

If no scene is specified the call:

```python
data_all_scenes = czi.read()
```

Will have the following defaults:
- ROI = total_bounding_rectangle = (0, 0, 2000, 1400)
- Planes = { 'C': 0, 'T': 0, 'Z': 0 }

And return the following data:

![read no roi](/doc/scenes/read_all_scenes.png)

If a scene is specified the call:

```python
data = czi.read(scene=1)
```

Will have the following defaults:
- ROI = scene_bounding_rectangle[1] = (0, 200, 1000, 1200)
- Planes = { 'C': 0, 'T': 0, 'Z': 0 }

And return the following data:

![read no roi](/doc/scenes/read_s1.png)

**Specifying ROI:**

Getting data from a specific ROI works exactly as specified above. The user needs to keep in mind that the ROI can span across different scenes.

![roi](/doc/scenes/roi.png)

```python
roi = (500, 0, 500, 700)

data_all_scenes = czi.read(roi=roi)
data_s1 = czi.read(roi=roi, scene=1)
```

Returns:

![read at roi](/doc/scenes/read_roi.png)


#### Images with uniform scenes

Let's consider an image with scenes of consistent shape, like a multi-well where each scene corresponds to a well.

![multi-well](/doc/scenes/multi_well.png)

The logic above is unaltered, but we will most likely not want to read data at ROIs spanning across multiple scenes. Instead, we would like to iterate over the scenes and get the scene/well data.

This can be done as follows:

```python
total_bounding_box = get_total_bounding_box()
scene_bounding_rectangle = czi.get_scene_bounding_rectangle()
total_bounding_rectangle = czi.get_total_bounding_rectangle()

print(total_bounding_box)
# {'X': (0, 1000), 'Y': (0, 1000)}
print(scene_bounding_rectangle)
# { 0: (0, 0, 400, 400), 1: (500, 0, 1000, 400), 2: (0, 500, 400, 1000), 3: (500, 500, 1000, 1000)}
print(total_bounding_rectangle)
# '(0, 0, 1000, 1000)'
```

```python

for s in scene_bounding_boxes.keys():
    roi = scene_bounding_boxes[s]
    data = czi.read(roi=roi)
```

This iteration returns the pixel data for each scene. There is no need to specify the scene_filter because the ROI is the scene bounding box and there are no overlapping scenes.


![iteration results](/doc/scenes/iteration_results.png)

### Handling Planes of Different Sizes

There are some CZIs where the size of the planes varies. Z-stacks acquired in the FiB-SEM are an example of this:

![image info](/doc/images/fib_stack.png)

This means that it's possible to get zones with invalid data in different planes.

The user can nevertheless access the data normally, but the assumption that the planes are correctly stacked is not guaranteed.

**All planes live in a common pixel-coordinate system. And this pixel-coordinate-system gives the spatial position. Everything else is a matter of interpretation.**

The standard way of defining ROIs to cover a plane will lead situations like the one below, where accessing Z=4 starting with a ROI (0,0, w, h) produces a bitmap with invalid data.

![image info](/doc/images/fib_stack_roi.png)
