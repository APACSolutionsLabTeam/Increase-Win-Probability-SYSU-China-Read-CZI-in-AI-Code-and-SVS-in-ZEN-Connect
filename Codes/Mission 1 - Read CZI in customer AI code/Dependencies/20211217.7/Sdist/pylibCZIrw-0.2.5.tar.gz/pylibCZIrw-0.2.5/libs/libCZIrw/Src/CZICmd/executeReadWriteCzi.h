#pragma once
#include "cmdlineoptions.h"

bool executeReadWriteCzi(const CCmdLineOptions& options);

