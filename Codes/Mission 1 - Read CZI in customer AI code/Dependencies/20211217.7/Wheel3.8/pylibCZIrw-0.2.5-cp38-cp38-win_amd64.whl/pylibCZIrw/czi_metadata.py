# Copyright 2021 Carl Zeiss Microscopy GmbH

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#    http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module implementing the CziMetadata class

The CziMetadata class parse and extracts information from the czi xml metadata.
"""
from __future__ import annotations

from collections import Counter
from itertools import zip_longest
from typing import List, Dict, Any, Optional, Union

import numpy as np
import pydash
import xmltodict


class CziMetadata:
    """CziMetadata class."""

    def __init__(self, raw_metadata: str) -> None:
        """Creates a CziMetadata object.

        Parameters
        ----------
        raw_metadata : str
            Czi Xml metadata.
        """
        metadata = xmltodict.parse(raw_metadata)

        # get SW version and acquisition data
        self.info = Info.from_dict(metadata)
        self.image = Image.from_dict(metadata)
        self.channelinfo = Channel.from_dict(metadata)
        self.scale = Scaling.from_dict(metadata)
        self.objective = Objectives.from_dict(metadata)
        self.detector = Detector.from_dict(metadata)
        self.microscope = Microscope.from_dict(metadata)
        self.wells = WellsInfo.from_dict(metadata)
        self.additional = Additional.from_dict(metadata)

    def create_metadata_dict(self) -> Dict:
        """Creates a metadata dictionary.

        Returns: dictionary with the metadata
        """
        metadata = {
            "AcqDate": self.info.acquisition_date,
            "SW-Name": self.info.software_name,
            "SW-Version": self.info.software_version,
            "SizeX": self.image.SizeX,
            "SizeY": self.image.SizeY,
            "SizeZ": self.image.SizeZ,
            "SizeC": self.image.SizeC,
            "SizeT": self.image.SizeT,
            "SizeS": self.image.SizeS,
            "SizeB": self.image.SizeB,
            "SizeM": self.image.SizeM,
            "SizeH": self.image.SizeH,
            "SizeI": self.image.SizeI,
            "ObjNA": self.objective.NA,
            "ObjMag": self.objective.mag,
            "ObjID": self.objective.ID,
            "ObjName": self.objective.name,
            "ObjImmersion": self.objective.immersion,
            "TubelensMag": self.objective.tubelensmag,
            "ObjNominalMag": self.objective.nominalmag,
            "XScale": self.scale.X,
            "YScale": self.scale.Y,
            "ZScale": self.scale.Z,
            "XScaleUnit": self.scale.XUnit,
            "YScaleUnit": self.scale.YUnit,
            "ZScaleUnit": self.scale.ZUnit,
            "DetectorModel": self.detector.model,
            "DetectorName": self.detector.name,
            "DetectorID": self.detector.ID,
            "DetectorType": self.detector.modeltype,
            "ChannelsNames": self.channelinfo.names,
            "ChannelShortNames": self.channelinfo.shortnames,
            "ChannelColors": self.channelinfo.colors,
            "WellArrayNames": self.wells.array_names,
            "WellIndices": self.wells.indices,
            "WellPositionNames": self.wells.position_names,
            "WellRowID": self.wells.rowID,
            "WellColumnID": self.wells.colID,
            "WellCounter": self.wells.counter,
            "SceneCenterStageX": self.wells.stageX,
            "SceneCenterStageY": self.wells.stageY,
        }

        return metadata


class Image:
    """Data structure for Image metadata.

    - "X":"Width"
    - "Y":"Height"
    - "C":"Channel"
    - "Z":"Slice"        # depth
    - "T":"Time"
    - "R":"Rotation"
    - "S":"Scene"        # contiguous regions of interest in a mosaic image
    - "I":"Illumination" # direction
    - "B":"Block"        # acquisition
    - "M":"Mosaic"       # index of tile for compositing a scene
    - "H":"Phase"        # e.g. Airy detector fibers
    - "V":"View"         # e.g. for SPIM
    """

    @staticmethod
    def _nan_int(value: Any) -> Optional[int]:
        """Converts to int if not None, otherwise returns None"""
        return int(value) if value is not None else None

    def __init__(self, image_dict: Dict[str, Any]) -> None:
        """Initialize Dimension information.

        Parameters:
        -----------
        image_dict
            Dictionary with information about the Image.
        """
        # dimensions
        self.SizeX = self._nan_int(image_dict.get("SizeX"))
        self.SizeY = self._nan_int(image_dict.get("SizeY"))
        self.SizeC = self._nan_int(image_dict.get("SizeC"))
        self.SizeZ = self._nan_int(image_dict.get("SizeZ"))
        self.SizeT = self._nan_int(image_dict.get("SizeT"))
        self.SizeM = self._nan_int(image_dict.get("SizeM"))
        self.SizeB = self._nan_int(image_dict.get("SizeB"))
        self.SizeS = self._nan_int(image_dict.get("SizeS"))
        self.SizeH = self._nan_int(image_dict.get("SizeH"))
        self.SizeI = self._nan_int(image_dict.get("SizeI"))
        self.SizeR = self._nan_int(image_dict.get("SizeR"))

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Image:
        """Create image info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(metadata, ["ImageDocument", "Metadata", "Information", "Image"]):
            return cls(metadata["ImageDocument"]["Metadata"]["Information"]["Image"])
        return cls({})


class Channel:
    """Data structure for channel metadata."""

    def __init__(self, channels: List[Dict[str, Any]]) -> None:
        """Initialize channel information.

        Parameters:
        -----------
        channels
            List of dictionaries with information about channels.
        """
        self.shortnames = []
        self.names = []
        self.colors = []
        self.contrast = []
        self.gamma = []

        for index, channel in enumerate(channels):
            self.shortnames.append(channel.get("ShortName", channel.get("DyeName", f"Dye-CH{index}")))
            self.names.append(channel.get("Name", channel.get("@Name", f"CH{index}")))
            self.colors.append(channel.get("Color", "80808000"))
            self.contrast.append([float(channel.get("Low", 0.0)), float(channel.get("High", 0.0))])
            self.gamma.append(float(channel.get("Gamma", 0.85)))

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Channel:
        """Create channel info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(metadata, ["ImageDocument", "Metadata", "Information", "Image", "SizeC"]):
            sizeC = int(metadata["ImageDocument"]["Metadata"]["Information"]["Image"]["SizeC"])
        else:
            sizeC = 1

        if pydash.objects.has(metadata, ["ImageDocument", "Metadata", "DisplaySetting", "Channels", "Channel"]):
            channels = metadata["ImageDocument"]["Metadata"]["DisplaySetting"]["Channels"]["Channel"]
            if sizeC == 1:
                channels = [channels]
            return cls(channels)
        return cls([])


class Scaling:
    """Data structure for scaling metadata."""

    def __init__(self, distance_dict: Optional[List[Dict[str, Any]]]) -> None:
        """Initialize scaling information.

        Parameters:
        -----------
        distance_dict
            Dictionary with information about distances.
        """
        self.X = 1.0
        self.Y = 1.0
        self.Z = 1.0
        self.XUnit = None
        self.YUnit = None
        self.ZUnit = None

        if distance_dict:

            try:
                self.X = float(distance_dict[0]["Value"]) * 1000000
                self.XUnit = str(distance_dict[0]["DefaultUnitFormat"])
            except IndexError:
                self.X = 1.0
                self.XUnit = None

            try:
                self.Y = float(distance_dict[1]["Value"]) * 1000000
                self.YUnit = str(distance_dict[1]["DefaultUnitFormat"])
            except IndexError:
                self.Y = 1.0
                self.YUnit = None

            try:
                self.Z = float(distance_dict[2]["Value"]) * 1000000
                self.ZUnit = str(distance_dict[2]["DefaultUnitFormat"])
            except IndexError:
                self.Z = 1.0
                self.ZUnit = None

            self.X = np.round(self.X, 3)
            self.Y = np.round(self.Y, 3)
            self.Z = np.round(self.Z, 3)

            # additional check for faulty z-scaling
            if self.Z == 0.0:
                self.Z = 1.0

        unit_conversion = {"µm": "micron"}

        # convert scale unit to avoid encoding problems
        self.XUnit = unit_conversion.get(self.XUnit, self.XUnit)  # type: ignore[arg-type]
        self.YUnit = unit_conversion.get(self.YUnit, self.YUnit)  # type: ignore[arg-type]
        self.ZUnit = unit_conversion.get(self.ZUnit, self.ZUnit)  # type: ignore[arg-type]

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Scaling:
        """Create scaling info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(metadata, ["ImageDocument", "Metadata", "Scaling", "Items", "Distance"]):
            return cls(metadata["ImageDocument"]["Metadata"]["Scaling"]["Items"]["Distance"])
        return cls(None)


class Info:
    """Data structure for general info about the document metadata."""

    def __init__(self, info_dict: Dict[str, Any]) -> None:
        """Initialize info metadata class.

        Parameters:
        -----------
        info_dict
            Dictionary with information about the document.
        """
        # get acquisition data and SW version
        self.software_name = info_dict.get("Application", {}).get("Name")
        self.software_version = info_dict.get("Application", {}).get("Version")
        self.acquisition_date = info_dict.get("Image", {}).get("AcquisitionDateAndTime")

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Info:
        """Create info object from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(metadata, ["ImageDocument", "Metadata", "Information"]):
            return cls(metadata["ImageDocument"]["Metadata"]["Information"])
        return cls({})


class Objectives:
    """Data structure for objectives metadata."""

    def __init__(
        self,
        tubelens_dicts: Optional[Union[List[Optional[Dict[str, Any]]], Dict[str, Any]]],
        objective_dicts: Optional[Union[List[Optional[Dict[str, Any]]], Dict[str, Any]]],
    ) -> None:
        """Initialize objectives information.

        Parameters:
        -----------
        tubelens_dicts
            Dictionary with information about tubelens.
        objective_dicts
            Dictionary with information about objective.
        """
        self.NA = []
        self.mag = []
        self.ID = []
        self.name = []
        self.immersion = []
        self.tubelensmag = []
        self.nominalmag = []

        if objective_dicts:
            if not isinstance(
                objective_dicts,
                list,
            ):
                objective_dicts = [objective_dicts]

            if not isinstance(
                tubelens_dicts,
                list,
            ):
                tubelens_dicts = [tubelens_dicts]

            for objective_dict, tubelens_dict in zip_longest(objective_dicts, tubelens_dicts):
                self.name.append(objective_dict.get("Name"))
                self.immersion.append(objective_dict.get("Immersion"))
                self.NA.append(float(objective_dict.get("LensNA")))
                self.ID.append(objective_dict.get("Id"))
                self.tubelensmag.append(float(tubelens_dict.get("Magnification", 1.0)))
                self.nominalmag.append(float(objective_dict.get("NominalMagnification", 1.0)))

            self.mag = list(np.multiply(self.nominalmag, self.tubelensmag))

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Objectives:
        """Create objectives info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        try:
            tubelens_dicts = metadata["ImageDocument"]["Metadata"]["Information"]["Instrument"]["TubeLenses"][
                "TubeLens"
            ]
        except KeyError:
            tubelens_dicts = {}

        try:
            objective_dicts = metadata["ImageDocument"]["Metadata"]["Information"]["Instrument"]["Objectives"][
                "Objective"
            ]
        except KeyError:
            objective_dicts = {}

        return cls(tubelens_dicts=tubelens_dicts, objective_dicts=objective_dicts)


class Detector:
    """Class for information about detector."""

    def __init__(self, detector_info: Optional[Union[List[Optional[Dict[str, Any]]], Dict[str, Any]]]) -> None:
        """Initialize detector information.

        Parameters
        ----------
        detector_info:
            detector information in form of dictionary
        """
        _detector_info = detector_info or []
        _detector_info = detector_info if isinstance(detector_info, list) else [detector_info]

        self.model = [detector.get("Manufacturer", {}).get("Model") for detector in _detector_info if detector]
        self.name = [detector.get("Name") for detector in _detector_info if detector]
        self.ID = [detector.get("ID") for detector in _detector_info if detector]
        self.modeltype = [detector.get("Type") for detector in _detector_info if detector]

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Detector:
        """Create detector info from dictionary containing all informations about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(
            metadata, ["ImageDocument", "Metadata", "Information", "Instrument", "Detectors", "Detector"]
        ):
            return cls(metadata["ImageDocument"]["Metadata"]["Information"]["Instrument"]["Detectors"]["Detector"])
        return cls(None)


class Microscope:
    """Class for microscope metadata"""

    def __init__(self, microscope: Optional[Dict[str, Any]]) -> None:
        """Initialize Microscope metadata.

        Parameters
        ----------
        microscope
            dictionary containing information about microscope
        """
        self.ID = None
        self.Name = None

        if microscope:
            self.ID = microscope.get("Id", microscope.get("@Id"))
            self.Name = microscope.get("System")

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Microscope:
        """Create microscopy info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(
            metadata, ["ImageDocument", "Metadata", "Information", "Instrument", "Microscopes", "Microscope"]
        ):
            return cls(metadata["ImageDocument"]["Metadata"]["Information"]["Instrument"]["Microscopes"]["Microscope"])
        return cls(None)


class WellsInfo:
    """Structure for wells information."""

    def __init__(self, scenes: Optional[List[Dict[str, Any]]]) -> None:
        """Initialize wells information class.

        Parameters
        -----------
        scenes
            List of dictionaries with information about wells.
        """
        self.array_names = []
        self.indices = []
        self.position_names = []
        self.colID = []
        self.rowID = []
        self.counter: Dict[str, int] = {}
        self.stageX = []
        self.stageY = []
        self.number = 0

        if scenes:
            for scene in scenes:
                self.array_names.append(scene.get("ArrayName", scene.get("Name", scene.get("@Name", "A1"))))
                self.indices.append(scene.get("Index", scene.get("@Index", 1)))
                self.position_names.append(scene.get("Name", scene.get("@Name", "P1")))
                self.colID.append(int(scene.get("Shape", {}).get("ColumnIndex", 0)))
                self.rowID.append(int(scene.get("Shape", {}).get("RowIndex", 0)))

                sx = scene.get("CenterPosition", "0,0").split(",")[0]
                sy = scene.get("CenterPosition", "0,0").split(",")[1]
                self.stageX.append(np.double(sx))
                self.stageY.append(np.double(sy))

            self.counter = Counter(self.array_names)
            self.number = len(self.counter.keys())

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> WellsInfo:
        """Create wells info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(
            metadata, ["ImageDocument", "Metadata", "Information", "Image", "Dimensions", "S", "Scenes", "Scene"]
        ):
            sizeS = int(metadata["ImageDocument"]["Metadata"]["Information"]["Image"]["SizeS"])
            scenes = metadata["ImageDocument"]["Metadata"]["Information"]["Image"]["Dimensions"]["S"]["Scenes"]["Scene"]
            if sizeS == 1:
                scenes = [scenes]
            return cls(scenes)
        return cls(None)


class Additional:
    """Class for additional metadata."""

    def __init__(self, metadata: Dict[str, Any]) -> None:
        """Initialize additional metadata by dictionary metadata.

        Parameters
        ------------
        metadata
            dictionary containing additional information
        """
        self.experiment = metadata.get("Experiment")
        self.hardware_setting = metadata.get("HardwareSetting")
        self.custom_attributes = metadata.get("CustomAttributes")
        self.display_setting = metadata.get("DisplaySetting")
        self.layers = metadata.get("Layers")

    @classmethod
    def from_dict(cls, metadata: Dict[str, Any]) -> Additional:
        """Create additional info from dictionary containing all information about czi.

        Parameters
        ----------
        metadata:
            czi file metadata dictionary
        """
        if pydash.objects.has(metadata, ["ImageDocument", "Metadata"]):
            return cls(metadata["ImageDocument"]["Metadata"])
        return cls({})
